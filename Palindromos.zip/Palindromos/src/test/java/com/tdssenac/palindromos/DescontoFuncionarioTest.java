
package com.tdssenac.palindromos;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class DescontoFuncionarioTest {
    
    @Test
    public void testDesenvolvedorSalarioMaiorQue3000() {
        Funcionario f = new Funcionario("João", 3500.0, Cargo.DESENVOLVEDOR);
        double desconto = DescontoFuncionario.calcularDesconto(f);
        assertEquals(3500.0 * 0.20, desconto);
    }

    @Test
    public void testDesenvolvedorSalarioMenorQue3000() {
        Funcionario f = new Funcionario("Maria", 2500.0, Cargo.DESENVOLVEDOR);
        double desconto = DescontoFuncionario.calcularDesconto(f);
        assertEquals(2500.0 * 0.10, desconto);
    }

    @Test
    public void testDBASalarioMaiorQue2500() {
        Funcionario f = new Funcionario("Carlos", 3000.0, Cargo.DBA);
        double desconto = DescontoFuncionario.calcularDesconto(f);
        assertEquals(3000.0 * 0.25, desconto);
    }

    @Test
    public void testDBASalarioMenorQue2500() {
        Funcionario f = new Funcionario("Ana", 2000.0, Cargo.DBA);
        double desconto = DescontoFuncionario.calcularDesconto(f);
        assertEquals(2000.0 * 0.15, desconto);
    }

    @Test
    public void testTestadorSalarioMaiorQue2500() {
        Funcionario f = new Funcionario("Luiz", 2700.0, Cargo.TESTADOR);
        double desconto = DescontoFuncionario.calcularDesconto(f);
        assertEquals(2700.0 * 0.25, desconto);
    }

    @Test
    public void testTestadorSalarioMenorQue2500() {
        Funcionario f = new Funcionario("Paula", 2300.0, Cargo.TESTADOR);
        double desconto = DescontoFuncionario.calcularDesconto(f);
        assertEquals(2300.0 * 0.15, desconto);
    }
    
}
