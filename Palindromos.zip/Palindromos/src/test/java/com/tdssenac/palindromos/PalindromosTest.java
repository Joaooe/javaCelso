
package com.tdssenac.palindromos;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class PalindromosTest {
    
     @Test
    public void testIsPalindromo() {
        Palindromos palindromo = new Palindromos();
        
        assertTrue(palindromo.isPalindromo("Anotaram a data da maratona"));
        assertTrue(palindromo.isPalindromo("Mussum"));
        assertTrue(palindromo.isPalindromo("Socorram me subi no onibus em marrocos")); 
}


}