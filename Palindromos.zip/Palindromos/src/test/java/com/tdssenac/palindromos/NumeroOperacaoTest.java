package com.tdssenac.palindromos;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class NumeroOperacaoTest {

    @Test
    public void testRealizarOperacao() {
        NumeroOperacao numeroOperacao = new NumeroOperacao();

        // Testando valores para garantir que a operação ocorre como esperado
        assertEquals(160, numeroOperacao.realizarOperacao(40));  // > 30, multiplica por 4
        assertEquals(36, numeroOperacao.realizarOperacao(12));   // > 10 e <= 30, multiplica por 3
        assertEquals(8, numeroOperacao.realizarOperacao(4));     // <= 10, multiplica por 2
    }
}


