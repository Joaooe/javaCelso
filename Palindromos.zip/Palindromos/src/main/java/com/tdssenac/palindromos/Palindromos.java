

package com.tdssenac.palindromos;


   public class Palindromos {

    public boolean isPalindromo(String frase) {
        String cleanPhrase = frase.replaceAll("[^a-zA-Z]", "").toLowerCase();
        StringBuilder reversed = new StringBuilder(cleanPhrase).reverse();
        return cleanPhrase.equals(reversed.toString());
    }
}


