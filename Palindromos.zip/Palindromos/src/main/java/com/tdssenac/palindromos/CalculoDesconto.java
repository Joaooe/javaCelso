
package com.tdssenac.palindromos;


public class CalculoDesconto {
    public static double calcularDesconto(Funcionario funcionario) {
        double desconto = 0.0;

        if (funcionario.getCargo() == Cargo.DESENVOLVEDOR) {
            if (funcionario.getSalario() > 3000.0) {
                desconto = 0.20; // 20% de desconto para Desenvolvedores com salário maior que R$ 3000,00
            } else {
                desconto = 0.10; // 10% de desconto para Desenvolvedores com salário menor ou igual a R$ 3000,00
            }
        } else if (funcionario.getCargo() == Cargo.DBA || funcionario.getCargo() == Cargo.TESTADOR) {
            if (funcionario.getSalario() > 2500.0) {
                desconto = 0.25; // 25% de desconto para DBAs e Testadores com salário maior que R$ 2500,00
            } else {
                desconto = 0.15; // 15% de desconto para DBAs e Testadores com salário menor ou igual a R$ 2500,00
            }
        }

        return funcionario.getSalario() * desconto; // Retorna o valor do desconto
    }

    public static void main(String[] args) {
        Funcionario f1 = new Funcionario("João", 3500.0, Cargo.DESENVOLVEDOR);
        Funcionario f2 = new Funcionario("Maria", 2500.0, Cargo.DESENVOLVEDOR);
        Funcionario f3 = new Funcionario("Carlos", 3000.0, Cargo.DBA);
        Funcionario f4 = new Funcionario("Ana", 2000.0, Cargo.DBA);

        // Teste dos descontos
        System.out.println("Desconto João (Desenvolvedor): " + calcularDesconto(f1));
        System.out.println("Desconto Maria (Desenvolvedor): " + calcularDesconto(f2));
        System.out.println("Desconto Carlos (DBA): " + calcularDesconto(f3));
        System.out.println("Desconto Ana (DBA): " + calcularDesconto(f4));
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
