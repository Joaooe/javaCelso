package com.tdssenac.palindromos;

public class DescontoFuncionario {
    
    // Método para calcular o desconto
    public static double calcularDesconto(Funcionario funcionario) {
        double desconto = 0.0;
        
        // Desconto para desenvolvedores
        if (funcionario.getCargo() == Cargo.DESENVOLVEDOR) {
            if (funcionario.getSalario() > 3000.0) {
                desconto = 0.20; // 20% de desconto para Desenvolvedores com salário maior que R$ 3000,00
            } else {
                desconto = 0.10; // 10% de desconto para Desenvolvedores com salário menor ou igual a R$ 3000,00
            }
        } 
        // Desconto para DBAs e Testadores
        else if (funcionario.getCargo() == Cargo.DBA || funcionario.getCargo() == Cargo.TESTADOR) {
            if (funcionario.getSalario() > 2500.0) {
                desconto = 0.25; // 25% de desconto para DBAs e Testadores com salário maior que R$ 2500,00
            } else {
                desconto = 0.15; // 15% de desconto para DBAs e Testadores com salário menor ou igual a R$ 2500,00
            }
        }

        // Retorna o valor do desconto calculado
        return funcionario.getSalario() * desconto; 
    }
}
