package com.tdssenac.palindromos;

public enum Cargo {
    DESENVOLVEDOR,
    DBA,
    TESTADOR;
}


